import { useEffect, useState } from "react";
import { FaRedo, FaSearch } from "react-icons/fa";

import { GlassCard } from "@/components/ui/glass-card";

import {
    getDashboardCentres,
    getDashboardDistricts,
    getDashboardStates,
} from "@/features/dashboard/services/DashboardFilterService";

// ============================================================
// Constants
// ============================================================

const EMPTY_FILTERS = Object.freeze({});

// Panel surface is a shadcn GlassCard (variant "panel") — see src/components/ui/glass-card.jsx.
// The filter only hosts native controls (no fixed-position children), so blur is safe here.
const PANEL_CLASS =
    "w-full rounded-[12px] border-[rgba(237,232,240,0.95)] bg-[rgba(249,247,251,0.72)] px-[12px] py-[10px]";

const CONTROL_STYLE = {
    width: "100%",
    height: "36px",
    padding: "0 0.65rem",
    fontSize: "0.78rem",
    color: "#2D2235",
    backgroundColor: "rgba(255, 255, 255, 0.86)",
    border: "1px solid #D8E2EF",
    borderRadius: "0.375rem",
    outline: "none",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.9), 0 1px 2px rgba(107,45,91,0.04)",
};

const SELECT_STYLE = {
    ...CONTROL_STYLE,
    paddingRight: "2.25rem",
    appearance: "none",
    backgroundImage:
        "url(\"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e\")",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "right 0.75rem center",
    backgroundSize: "16px 12px",
};

const BUTTON_BASE_STYLE = {
    height: "36px",
    minWidth: "84px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "6px",
    padding: "0 16px",
    fontSize: "13px",
    fontWeight: 500,
    whiteSpace: "nowrap",
    borderRadius: "8px",
    cursor: "pointer",
};

const SEARCH_STYLE = {
    ...BUTTON_BASE_STYLE,
    backgroundColor: "#6B2D5B",
    border: "1px solid #6B2D5B",
    color: "#fff",
};

const RESET_STYLE = {
    ...BUTTON_BASE_STYLE,
    backgroundColor: "#fff",
    border: "1px solid #6B2D5B",
    color: "#6B2D5B",
};

// ============================================================
// Helpers
// ============================================================

const areFiltersEqual = (current, next) => {
    const currentKeys = Object.keys(current);
    const nextKeys = Object.keys(next);

    if (currentKeys.length !== nextKeys.length) {
        return false;
    }

    return currentKeys.every((key) => current[key] === next[key]);
};

const createFilters = ({
    stateId,
    districtId,
    centreId,
    fromDate,
    toDate,
}) =>
    Object.fromEntries(
        Object.entries({
            state_id: stateId,
            district_id: districtId,
            centre_id: centreId,
            from_date: fromDate,
            to_date: toDate,
        }).filter(([, value]) => value)
    );

// ============================================================
// Component
// ============================================================

export default function DashboardFilter({ setFilters }) {
    const [states, setStates] = useState([]);
    const [districts, setDistricts] = useState([]);
    const [centres, setCentres] = useState([]);

    const [stateId, setStateId] = useState("");
    const [districtId, setDistrictId] = useState("");
    const [centreId, setCentreId] = useState("");

    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");

    // ========================================================
    // Load States
    // ========================================================

    useEffect(() => {
        let isCurrentRequest = true;

        const loadStates = async () => {
            try {
                const response = await getDashboardStates();

                if (isCurrentRequest) {
                    setStates(Array.isArray(response) ? response : []);
                }
            } catch {
                if (isCurrentRequest) {
                    setStates([]);
                }
            }
        };

        loadStates();

        return () => {
            isCurrentRequest = false;
        };
    }, []);

    // ========================================================
    // Load Districts
    // ========================================================

    useEffect(() => {
        let isCurrentRequest = true;

        if (!stateId) {
            setDistricts([]);
            setCentres([]);
            return () => {
                isCurrentRequest = false;
            };
        }

        const loadDistricts = async () => {
            try {
                const response = await getDashboardDistricts(stateId);

                if (isCurrentRequest) {
                    setDistricts(Array.isArray(response) ? response : []);
                }
            } catch {
                if (isCurrentRequest) {
                    setDistricts([]);
                }
            }
        };

        loadDistricts();

        return () => {
            isCurrentRequest = false;
        };
    }, [stateId]);

    // ========================================================
    // Load Centres
    // ========================================================

    useEffect(() => {
        let isCurrentRequest = true;

        if (!stateId || !districtId) {
            setCentres([]);
            return () => {
                isCurrentRequest = false;
            };
        }

        const loadCentres = async () => {
            try {
                const response = await getDashboardCentres(
                    stateId,
                    districtId
                );

                if (isCurrentRequest) {
                    setCentres(Array.isArray(response) ? response : []);
                }
            } catch {
                if (isCurrentRequest) {
                    setCentres([]);
                }
            }
        };

        loadCentres();

        return () => {
            isCurrentRequest = false;
        };
    }, [stateId, districtId]);

    // ========================================================
    // Search
    // ========================================================

    const handleSearch = () => {
        const nextFilters = createFilters({
            stateId,
            districtId,
            centreId,
            fromDate,
            toDate,
        });

        setFilters((current) =>
            areFiltersEqual(current, nextFilters) ? current : nextFilters
        );
    };

    // ========================================================
    // Reset
    // ========================================================

    const handleReset = () => {
        setStateId("");
        setDistrictId("");
        setCentreId("");
        setFromDate("");
        setToDate("");

        setDistricts([]);
        setCentres([]);

        setFilters((current) =>
            areFiltersEqual(current, EMPTY_FILTERS) ? current : EMPTY_FILTERS
        );
    };

    // ========================================================
    // Render
    // ========================================================

    return (
        <div className="w-full px-[20px]">
            <GlassCard variant="panel" className={PANEL_CLASS}>
                <div className="flex flex-wrap items-center gap-[16px]">
                    {/* State */}

                    <div className="min-w-[170px] flex-1">
                        <select
                            value={stateId}
                            style={SELECT_STYLE}
                            onChange={(event) => {
                                const value = event.target.value;

                                setStateId(value);
                                setDistrictId("");
                                setCentreId("");
                            }}
                        >
                            <option value="">Select State</option>

                            {states.map((state) => (
                                <option
                                    key={state.state_lgd_code}
                                    value={state.state_lgd_code}
                                >
                                    {state.state_name}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* District */}

                    <div className="min-w-[170px] flex-1">
                        <select
                            value={districtId}
                            style={SELECT_STYLE}
                            disabled={!stateId}
                            onChange={(event) => {
                                const value = event.target.value;

                                setDistrictId(value);
                                setCentreId("");
                            }}
                        >
                            <option value="">Select District</option>

                            {districts.map((district) => (
                                <option
                                    key={district.district_lgd_code}
                                    value={district.district_lgd_code}
                                >
                                    {district.district_name}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Centre */}

                    <div className="min-w-[170px] flex-1">
                        <select
                            value={centreId}
                            style={SELECT_STYLE}
                            disabled={!districtId}
                            onChange={(event) =>
                                setCentreId(event.target.value)
                            }
                        >
                            <option value="">Select Centre</option>

                            {centres.map((centre) => (
                                <option
                                    key={centre.centre_id}
                                    value={centre.centre_id}
                                >
                                    {centre.centre_name}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* From Date */}

                    <div className="min-w-[160px] flex-1">
                        <input
                            type="date"
                            value={fromDate}
                            style={CONTROL_STYLE}
                            onChange={(event) =>
                                setFromDate(event.target.value)
                            }
                        />
                    </div>

                    {/* To Date */}

                    <div className="min-w-[160px] flex-1">
                        <input
                            type="date"
                            value={toDate}
                            style={CONTROL_STYLE}
                            onChange={(event) =>
                                setToDate(event.target.value)
                            }
                        />
                    </div>

                    {/* Search */}

                    <button
                        type="button"
                        style={SEARCH_STYLE}
                        onClick={handleSearch}
                    >
                        <FaSearch size={12} />
                        Search
                    </button>

                    {/* Reset */}

                    <button
                        type="button"
                        style={RESET_STYLE}
                        onClick={handleReset}
                    >
                        <FaRedo size={11} />
                        Reset
                    </button>
                </div>
            </GlassCard>
        </div>
    );
}