import { memo } from "react";

import { GlassIcon, useSpotlight } from "@/components/ui/glass-card";
import {
    FaBuilding,
    FaCubes,
    FaFileAlt,
    FaLayerGroup,
    FaUsers,
} from "react-icons/fa";

// ============================================================
// Static configuration
// ============================================================

const STATS_CONFIG = [
    {
        key: "centres",
        label: "Centres",
        icon: FaBuilding,
        gradient:
            "bg-[linear-gradient(120deg,#3f5a52_0%,#5d8479_45%,#a9ccc0_100%)]",
        glow: "shadow-[0_10px_22px_-8px_rgba(214,178,74,0.55)]",
    },
    {
        key: "trainees",
        label: "Trainees",
        icon: FaUsers,
        gradient:
            "bg-[linear-gradient(120deg,#4a2242_0%,#3d4f61_55%,#2f7e7c_100%)]",
        glow: "shadow-[0_10px_22px_-8px_rgba(56,132,196,0.55)]",
    },
    {
        key: "modules",
        label: "Modules",
        icon: FaCubes,
        gradient:
            "bg-[linear-gradient(120deg,#dcaad2_0%,#b96bad_55%,#8e3b8a_100%)]",
        glow: "shadow-[0_10px_22px_-8px_rgba(129,180,229,0.55)]",
    },
    {
        key: "batches",
        label: "Batches",
        icon: FaLayerGroup,
        gradient:
            "bg-[linear-gradient(120deg,#28352d_0%,#41544a_55%,#75847a_100%)]",
        glow: "shadow-[0_10px_22px_-8px_rgba(96,180,120,0.55)]",
    },
    {
        key: "documents",
        label: "Documents",
        icon: FaFileAlt,
        gradient:
            "bg-[linear-gradient(120deg,#33101c_0%,#5c1e26_55%,#7e2f30_100%)]",
        glow: "shadow-[0_10px_22px_-8px_rgba(228,110,130,0.55)]",
    },
];

// ============================================================
// Component
// ============================================================

function StatsCards({
    centres = 0,
    trainees = 0,
    modules = 0,
    batches = 0,
    documents = 0,
}) {
    const values = {
        centres,
        trainees,
        modules,
        batches,
        documents,
    };

    // Mouse-tracked highlight for the tiles (see .glass-spot in index.css).
    const handleSpotlight = useSpotlight(true, undefined, { tilt: true, maxTilt: 4 });

    return (
        <section className="w-full pb-[20px] pt-0">
            <div className="grid w-full grid-cols-1 items-stretch gap-[20px] sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                {STATS_CONFIG.map(
                    ({ key, label, icon: Icon, gradient, glow }) => (
                        <div
                            key={key}
                            className={`glass-tilt group relative flex min-h-[124px] h-full cursor-pointer flex-col justify-center overflow-hidden rounded-[14px] ring-1 ring-inset ring-white/20 px-[18px] py-4 transition-transform duration-300 ease-out hover:-translate-y-[6px] hover:shadow-[0_18px_30px_-10px_rgba(0,0,0,0.35)] ${gradient} ${glow}`}
                            onMouseMove={handleSpotlight}
                        >
                            {/* Decorative circles */}

                            <span className="pointer-events-none absolute -bottom-14 -right-[26px] h-[150px] w-[150px] rounded-full bg-white/[0.10]" />

                            <span className="pointer-events-none absolute -bottom-[70px] right-[54px] h-[120px] w-[120px] rounded-full bg-white/[0.07]" />

                            <span className="pointer-events-none absolute -right-4 -top-[34px] h-[92px] w-[92px] rounded-full bg-white/[0.07]" />

                            {/* Spotlight (follows the cursor) */}
                            <span className="glass-spot" aria-hidden="true" />

                            {/* Content */}

                            <div className="relative z-[1] flex flex-row items-center justify-between gap-3">
                                <div className="flex min-w-0 flex-col">
                                    <span className="block whitespace-nowrap font-['Open_Sans'] text-[13px] font-semibold uppercase leading-[18px] tracking-[0.06em] text-white">
                                        {label}
                                    </span>

                                    <span className="mt-[6px] block font-['Open_Sans'] text-[30px] font-bold leading-[38px] text-white">
                                        {values[key]}
                                    </span>
                                </div>

                                <GlassIcon className="h-[52px] w-[52px] transition-transform duration-300 group-hover:scale-110 group-hover:bg-white/[0.28]">
                                    <Icon
                                        size={22}
                                        className="text-white"
                                        aria-hidden="true"
                                    />
                                </GlassIcon>
                            </div>
                        </div>
                    )
                )}
            </div>
        </section>
    );
}

// Prevent re-render when dashboard statistics haven't changed.
export default memo(StatsCards);