import { lazy, Suspense, useEffect, useState } from "react";

import AppLayout from "@/components/layout/AppLayout";

import DashboardFilter from "./components/DashboardFilter";
import StatsCards from "./components/DashboardStats";

const loadDashboardCharts = () => import("./components/DashboardCharts");
const DashboardCharts = lazy(loadDashboardCharts);
// Start fetching the charts chunk while the summary API call is in flight.
loadDashboardCharts();

import { getDashboardSummary } from "./services/DashboardService";

export default function Dashboard() {
    // Start in the loading state so the spinner shows immediately on mount
    // until the first dashboard payload arrives.
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({});
    const [dashboardSummary, setDashboardSummary] = useState(null);

    useEffect(() => {
        let isCurrentRequest = true;

        const fetchDashboard = async () => {
            try {
                setLoading(true);

                const response = await getDashboardSummary(filters);

                if (isCurrentRequest) {
                    setDashboardSummary(response);
                }
            } catch (error) {
                if (isCurrentRequest) {
                    console.error("Dashboard load error:", error);
                }
            } finally {
                if (isCurrentRequest) {
                    setLoading(false);
                }
            }
        };

        fetchDashboard();

        return () => {
            isCurrentRequest = false;
        };
    }, [filters]);

    return (
        <AppLayout>
            <main className="relative min-h-screen bg-[#EDF2F9]  ">

                {/* Slim progress bar while a filter refetch is in flight (page stays visible). */}
                {loading && dashboardSummary && (
                    <div className="glass-progress pointer-events-none absolute inset-x-0 top-0 z-[1000] h-[3px] overflow-hidden">
                        <span className="glass-progress-bar block h-full w-1/3 rounded-full bg-[#732269]" />
                    </div>
                )}

                {!dashboardSummary && (
                    <div className="glass-anim-fade absolute inset-0 z-[1000] flex min-h-screen flex-col items-center justify-center gap-4 bg-[#EDF2F9]">
                        <span className="h-14 w-14 animate-spin rounded-full border-4 border-[#DBD3E2] border-t-[#6B2D5B]" />
                        <span className="text-[14px] font-semibold tracking-wide text-[#6B2D5B]">
                            Loading dashboard...
                        </span>
                    </div>
                )}

                <div className={`px-[20px] pb-[20px] transition-opacity duration-300 ${loading && dashboardSummary ? "opacity-60" : "opacity-100"}`}>
                <div className="glass-card rounded-[12px] p-[20px]">

                {/* Filter */}
                <DashboardFilter
                    setFilters={setFilters}
                />

                <div className="mt-[20px]">
                    {/* Stats */}
                    <StatsCards
                        centres={
                            dashboardSummary?.summary?.total_centres ?? 0
                        }
                        trainees={
                            dashboardSummary?.summary?.total_participants ?? 0
                        }
                        modules={
                            dashboardSummary?.summary?.total_modules ?? 0
                        }
                        batches={
                            dashboardSummary?.summary?.total_batches ?? 0
                        }
                        documents={
                            dashboardSummary?.summary?.total_documents ?? 0
                        }
                    />
                </div>


                {/* Charts */}
                <Suspense fallback={null}>
                    <DashboardCharts
                        data={dashboardSummary || {}}
                        loading={loading}
                        filters={filters}
                    />
                </Suspense>

                </div>
                </div>

            </main>
        </AppLayout>
    );
}
