from sqlalchemy import func
from sqlalchemy.orm import Session

from app.modules.document.model import TopicMaster
from app.modules.module.model import ModuleMaster


class TopicRepository:

    @staticmethod
    def get_topics(
        db: Session,
        language_id: int,
        search: str | None,
        skip: int,
        limit: int,
    ):
        # Each language has its own independent TopicMaster rows (linked
        # only by a shared parent_id for translation lookups). The list for
        # a given language must show ONLY that language's own rows, so
        # counts and "newest first" ordering are fully language-specific.
        query = (
            db.query(
                TopicMaster.topic_id,
                TopicMaster.topic_name,
                ModuleMaster.module_name,
                TopicMaster.is_active.label("status"),
            )
            .join(
                ModuleMaster,
                ModuleMaster.module_id == TopicMaster.module_id,
            )
            .filter(
                TopicMaster.language_id == language_id,
            )
        )

        if search:
            query = query.filter(
                TopicMaster.topic_name.ilike(f"%{search}%")
            )

        count_query = (
            db.query(func.count(func.distinct(TopicMaster.topic_id)))
            .join(
                ModuleMaster,
                ModuleMaster.module_id == TopicMaster.module_id,
            )
            .filter(TopicMaster.language_id == language_id)
        )

        if search:
            count_query = count_query.filter(
                TopicMaster.topic_name.ilike(f"%{search}%")
            )

        total = count_query.scalar() or 0

        # Newest topics first (a just-added topic shows at the top).
        rows = (
            query.order_by(TopicMaster.topic_id.desc())
            .offset(skip)
            .limit(limit)
            .all()
        )

        records = [
            {
                "topic_id": row.topic_id,
                "topic_name": row.topic_name,
                "module_name": row.module_name,
                "language_id": language_id,
                "status": row.status,
            }
            for row in rows
        ]

        return records, total

    @staticmethod
    def get_topic_by_id(
        db: Session,
        topic_id: int,
    ):

        parent_id = (
            db.query(TopicMaster.parent_id)
            .filter(TopicMaster.topic_id == topic_id)
            .scalar()
        )

        if not parent_id:
            return None

        topics = (
            db.query(
                TopicMaster.topic_id,
                TopicMaster.module_id,
                TopicMaster.parent_id,
                TopicMaster.topic_name,
                TopicMaster.language_id,
                TopicMaster.is_active.label("status"),
                ModuleMaster.module_name,
            )
            .join(
                ModuleMaster,
                ModuleMaster.module_id == TopicMaster.module_id,
            )
            .filter(
                TopicMaster.parent_id == parent_id,
            )
            .order_by(TopicMaster.language_id.asc())
            .all()
        )

        return topics

    @staticmethod
    def delete_topic(
        db: Session,
        topic_id: int,
    ):

        topic = (
            db.query(TopicMaster)
            .filter(TopicMaster.topic_id == topic_id)
            .first()
        )

        if not topic:
            return False

        db.query(TopicMaster).filter(
            TopicMaster.parent_id == topic.parent_id
        ).delete(synchronize_session=False)

        db.commit()

        return True

    @staticmethod
    def create_topics(
        db: Session,
        module_id: int,
        topics: list,
        language_id: int = 1,
    ):

        created_topics = []

        for item in topics:

            # A topic added from any language tab is a fully independent
            # record (self-parented), not a translation of anything.
            # Translations are created separately via save_translation.
            topic = TopicMaster(
                module_id=module_id,
                language_id=language_id,
                topic_name=item.topic_name,
                is_active=item.is_active,
            )

            db.add(topic)
            db.flush()

            topic.parent_id = topic.topic_id

            created_topics.append(topic)

        db.commit()

        for topic in created_topics:
            db.refresh(topic)

        return created_topics



    @staticmethod
    def save_translation(
        db: Session,
        topic_id: int,
        language_id: int,
        topic_name: str,
        is_active: str,
    ):
        # Find English (or parent) record
        parent = (
            db.query(TopicMaster)
            .filter(TopicMaster.topic_id == topic_id)
            .first()
        )

        if not parent:
            return None

        parent_id = parent.parent_id

        # Check if translation already exists
        translation = (
            db.query(TopicMaster)
            .filter(
                TopicMaster.parent_id == parent_id,
                TopicMaster.language_id == language_id,
            )
            .first()
        )

        if translation:
            # Update existing translation
            translation.topic_name = topic_name
            translation.is_active = is_active

        else:
            # Insert new translation
            translation = TopicMaster(
                parent_id=parent_id,
                module_id=parent.module_id,
                language_id=language_id,
                topic_name=topic_name,
                is_active=is_active,
            )

            db.add(translation)

        db.commit()
        db.refresh(translation)

        return translation



    @staticmethod
    def update_topic(
        db: Session,
        topic_id: int,
        module_id: int,
        topic_name: str,
        is_active: str,
    ):

        topic = (
            db.query(TopicMaster)
            .filter(
                TopicMaster.topic_id == topic_id
            )
            .first()
        )

        if not topic:
            return None

        topic.module_id = module_id
        topic.topic_name = topic_name
        topic.is_active = is_active

        db.commit()
        db.refresh(topic)

        return topic
 
 
    @staticmethod
    def get_topic_translation(
        db: Session,
        topic_id: int,
        language_id: int,
    ):
        english = (
            db.query(TopicMaster)
            .filter(
                TopicMaster.topic_id == topic_id
            )
            .first()
        )

        if not english:
            return None

        if language_id == 1:
            return {
                "topic_id": english.topic_id,
                "topic_name": english.topic_name,
                "module_id": english.module_id,
                "status": english.is_active,
            }

        translation = (
            db.query(TopicMaster)
            .filter(
                TopicMaster.parent_id == english.parent_id,
                TopicMaster.language_id == language_id,
                TopicMaster.is_active == "1",
            )
            .first()
        )

        if translation:
            return {
                "topic_id": translation.topic_id,
                "topic_name": translation.topic_name,
                "module_id": translation.module_id,
                "status": translation.is_active,
            }

        return {
            "topic_id": english.topic_id,
            "topic_name": "",
            "module_id": english.module_id,
            "status": english.is_active,
        }