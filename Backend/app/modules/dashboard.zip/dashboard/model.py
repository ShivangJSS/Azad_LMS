from sqlalchemy import (
    BigInteger,
    Column,
    DateTime,
    Integer,
    Numeric,
    String,
    Date,
    Text,
)

from app.database.database import Base


class ParticipantModule(Base):
    __tablename__ = "participant_module"

    participant_module_id = Column(Integer, primary_key=True)

    participant_id = Column(Integer)

    course_id = Column(Integer)

    module_id = Column(Integer)

    lock_status = Column(Integer)

    status = Column(String)

    start_date = Column(Date)

    end_date = Column(Date)

    initiated_mode = Column(String)

    initiated_by = Column(Integer)

class DocumentCategory(Base):
    __tablename__ = "document_categories"

    doc_category_id = Column(Integer, primary_key=True, index=True)
    doc_category_name = Column(String)
    status = Column(Integer)
    language_id = Column(Integer)    


class DropBucketMaster(Base):
    __tablename__ = "drop_bucket_masters"

    drop_bucket_id = Column(BigInteger, primary_key=True)

    parent_id = Column(BigInteger)

    drop_bucket_question_title = Column(String(500))

    drop_bucket_question_description = Column(Text)

    image_url = Column(String(500))

    status = Column(Integer)

    marks = Column(Numeric(6, 2))

    created_at = Column(DateTime)

    updated_at = Column(DateTime)

    deleted_at = Column(DateTime)

    language_id = Column(BigInteger)


    
class DropBucket(Base):
    __tablename__ = "drop_buckets"

    bucket_id = Column(BigInteger, primary_key=True)

    drop_bucket_id = Column(BigInteger)

    bucket_name = Column(String(500))

    bucket_image = Column(String(1000))

    status = Column(Integer)

    created_at = Column(DateTime)

    updated_at = Column(DateTime)

    deleted_at = Column(DateTime)

    language_id = Column(BigInteger)


class DropBucketItem(Base):
    __tablename__ = "drop_bucket_items"

    drop_bucket_item_id = Column(BigInteger, primary_key=True)

    bucket_id = Column(BigInteger)

    item_name = Column(String(500))

    item_image = Column(String(1000))

    status = Column(Integer)

    created_at = Column(DateTime)

    updated_at = Column(DateTime)

    deleted_at = Column(DateTime)

    language_id = Column(BigInteger)