from sqlalchemy import (
    Column,
    BigInteger,
    Integer,
    String,
    Text,
    ForeignKey,
    Date
)
from sqlalchemy.orm import relationship

from app.database.database import Base


class ParticipantFeedback(Base):
    __tablename__ = "participant_feedback"

    feedback_id = Column(
        BigInteger,
        primary_key=True,
        index=True
    )

    participant_id = Column(
        BigInteger,
        nullable=False
    )

    lms_experience = Column(
        String(50),
        nullable=True
    )

    lms_ease = Column(
        String(50),
        nullable=True
    )

    useful_modules = Column(
        Text,
        nullable=True
    )


class ParticipantMoodAnswer(Base):
    __tablename__ = "participant_mood_answers"

    answer_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    participant_id = Column(
        BigInteger,
        nullable=False
    )

    question_id = Column(
        Integer,
        ForeignKey(
            "mood_questions_master.question_id"
        ),
        nullable=False
    )

    selected_option_id = Column(
        Integer,
        ForeignKey(
            "question_options.option_id"
        ),
        nullable=False
    )

    answer_time = Column(
        Date,
        nullable=True
    )

    lat = Column(
        String(100),
        nullable=True
    )

    long = Column(
        String(100),
        nullable=True
    )

    appversion = Column(
        String(50),
        nullable=True
    )

    status = Column(
        String(50),
        nullable=True
    )

    question = relationship(
        "MoodQuestionMaster"
    )


class MoodQuestionMaster(Base):
    __tablename__ = "mood_questions_master"

    question_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    question_name = Column(
        Text,
        nullable=False
    )

    question_description = Column(
        Text,
        nullable=True
    )

    question_type = Column(
        String(255),
        nullable=False
    )

    language_id = Column(
        Integer,
        nullable=False
    )

    is_active = Column(
        Integer,
        nullable=False,
        default=1
    )

    options = relationship(
        "QuestionOption",
        back_populates="question",
        lazy="joined"
    )


class QuestionOption(Base):
    __tablename__ = "question_options"

    option_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    question_id = Column(
        Integer,
        ForeignKey(
            "mood_questions_master.question_id"
        ),
        nullable=False
    )

    option_name = Column(
        String(255),
        nullable=False
    )

    option_icon = Column(
        String(255),
        nullable=True
    )

    language_id = Column(
        Integer,
        nullable=False
    )

    is_active = Column(
        Integer,
        nullable=False,
        default=1
    )

    question = relationship(
        "MoodQuestionMaster",
        back_populates="options"
    )