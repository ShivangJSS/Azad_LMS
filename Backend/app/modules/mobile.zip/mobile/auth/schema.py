from pydantic import BaseModel, Field, ConfigDict
from typing import Optional


# -------------------------
# Login Request
# -------------------------
class MobileLoginRequest(BaseModel):
    username: str = Field(
        ...,
        min_length=3,
        max_length=255,
        description="Participant username",
        examples=["ramita"],
    )

    password: str = Field(
        ...,
        min_length=6,
        max_length=255,
        description="Participant password",
        examples=["Password@123"],
    )


# -------------------------
# Refresh Token Request
# -------------------------
class RefreshTokenRequest(BaseModel):
    refresh_token: str = Field(
        ...,
        description="Refresh token",
    )


# -------------------------
# Logout Request
# -------------------------
class LogoutRequest(BaseModel):
    refresh_token: Optional[str] = Field(
        default=None,
        description="Refresh token (optional)",
    )


# -------------------------
# Participant Response
# -------------------------
class ParticipantResponse(BaseModel):
    participant_id: int
    enrollment_no: str
    participant_name: str
    username: str

    email: Optional[str] = None
    mobile_no: Optional[str] = None
    images: Optional[str] = None

    progress_status: Optional[int] = 0
    course_progress: Optional[int] = 0

    model_config = ConfigDict(from_attributes=True)


# -------------------------
# Login Response
# -------------------------
class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"

    participant: ParticipantResponse


# -------------------------
# Refresh Response
# -------------------------
class RefreshTokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"


# -------------------------
# Logout Response
# -------------------------
class LogoutResponse(BaseModel):
    message: str


# -------------------------
# Authenticated Participant
# -------------------------
class CurrentParticipantResponse(BaseModel):
    participant: ParticipantResponse