from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.database import get_db

from app.modules.mobile.auth.controller import MobileAuthController
from app.modules.mobile.core.dependencies import get_current_participant

from app.modules.mobile.auth.schema import (
    MobileLoginRequest,
    LoginResponse,
    RefreshTokenRequest,
    RefreshTokenResponse,
    LogoutResponse,
    ParticipantResponse,
)

router = APIRouter(
    prefix="/mobile/auth",
    tags=["Mobile Authentication"],
)


@router.post(
    "/login",
    response_model=LoginResponse,
)
def login(
    request: MobileLoginRequest,
    db: Session = Depends(get_db),
):
    return MobileAuthController.login(
        db=db,
        request=request,
    )


@router.post(
    "/refresh",
    response_model=RefreshTokenResponse,
)
def refresh_token(
    request: RefreshTokenRequest,
    db: Session = Depends(get_db),
):
    return MobileAuthController.refresh_token(
        db=db,
        request=request,
    )


@router.post(
    "/logout",
    response_model=LogoutResponse,
)
def logout():
    return MobileAuthController.logout()


@router.get(
    "/me",
    response_model=ParticipantResponse,
)
def get_me(
    participant=Depends(get_current_participant),
    db: Session = Depends(get_db),
):
    return MobileAuthController.get_current_participant(
        db=db,
        participant_id=participant.participant_id,
    )