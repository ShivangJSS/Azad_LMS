from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.modules.mobile.core.constants import (
    SECRET_KEY,
    ALGORITHM,
    ACCESS_TOKEN_EXPIRE_MINUTES,
    REFRESH_TOKEN_EXPIRE_DAYS,
)

# ------------------------------------------------------------------
# Password Context
# ------------------------------------------------------------------

pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
)


# ------------------------------------------------------------------
# Password Hash
# ------------------------------------------------------------------

def hash_password(password: str) -> str:
    """
    Generate bcrypt hash.
    """
    return pwd_context.hash(password)


# ------------------------------------------------------------------
# Password Verify
# ------------------------------------------------------------------

def verify_password(
    plain_password: str,
    hashed_password: str,
) -> bool:
    """
    Verify participant password.
    """
    return pwd_context.verify(
        plain_password,
        hashed_password,
    )


# ------------------------------------------------------------------
# Access Token
# ------------------------------------------------------------------

def create_access_token(
    participant_id: int,
    username: str,
) -> str:
    """
    Create JWT access token.
    """

    expire = datetime.now(timezone.utc) + timedelta(
        minutes=ACCESS_TOKEN_EXPIRE_MINUTES
    )

    payload = {
     "sub": str(participant_id),
     "participant_id": participant_id,
     "username": username,
     "token_type": "access",
     "iss": "azad-mobile",
     "exp": expire,
}

    return jwt.encode(
        payload,
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


# ------------------------------------------------------------------
# Refresh Token
# ------------------------------------------------------------------

def create_refresh_token(
    participant_id: int,
    username: str,
) -> str:
    """
    Create JWT refresh token.
    """

    expire = datetime.now(timezone.utc) + timedelta(
        days=REFRESH_TOKEN_EXPIRE_DAYS
    )

    payload = {
     "sub": str(participant_id),
     "participant_id": participant_id,
     "username": username,
     "token_type": "refresh",
     "iss": "azad-mobile",
     "exp": expire,
}

    return jwt.encode(
        payload,
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


# ------------------------------------------------------------------
# Decode Token
# ------------------------------------------------------------------

def decode_token(
    token: str,
) -> Optional[dict[str, Any]]:
    """
    Decode JWT token.
    """

    try:
        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM],
        )

        return payload

    except JWTError:
        return None


# ------------------------------------------------------------------
# Get Participant ID From Token
# ------------------------------------------------------------------

def get_participant_id_from_token(
    token: str,
) -> Optional[int]:
    """
    Extract participant_id from JWT.
    """

    payload = decode_token(token)

    if payload is None:
        return None

    return payload.get("participant_id")


# ------------------------------------------------------------------
# Check Token Type
# ------------------------------------------------------------------

def is_access_token(token: str) -> bool:
    payload = decode_token(token)

    if payload is None:
        return False

    return payload.get("token_type") == "access"


def is_refresh_token(token: str) -> bool:
    payload = decode_token(token)

    if payload is None:
        return False

    return payload.get("token_type") == "refresh"