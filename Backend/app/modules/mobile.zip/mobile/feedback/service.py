from sqlalchemy.orm import Session

from .repository import FeedbackRepository
from .schema import (
    FeedbackCreate,
    FeedbackResponse
)


class FeedbackService:

    @staticmethod
    def save_feedback(
        db: Session,
        payload: FeedbackCreate
    ) -> FeedbackResponse:

        feedback = FeedbackRepository.create_feedback(
            db=db,
            payload=payload
        )

        return FeedbackResponse(
            feedback_id=feedback.feedback_id,
            message="Feedback submitted successfully"
        )

    @staticmethod
    def get_questions(
        db: Session,
        language_id: int
    ):
        questions = FeedbackRepository.get_questions_by_language(
            db=db,
            language_id=language_id
        )

        return questions