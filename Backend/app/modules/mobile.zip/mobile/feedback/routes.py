from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.database import get_db

from .schema import (
    FeedbackCreate,
    MoodQuestionResponse
)
from .service import FeedbackService


router = APIRouter(
    prefix="/mobile/feedback",
    tags=["Mobile Feedback"]
)


@router.post("/submit")
def submit_feedback(
    payload: FeedbackCreate,
    db: Session = Depends(get_db)
):
    return FeedbackService.save_feedback(
        db=db,
        payload=payload
    )


@router.get(
    "/questions",
    response_model=list[MoodQuestionResponse]
)
def get_feedback_questions(
    language_id: int,
    db: Session = Depends(get_db)
):
    return FeedbackService.get_questions(
        db=db,
        language_id=language_id
    )