import json
from datetime import date

from sqlalchemy.orm import Session, joinedload

from app.modules.mobile.model import (
    ParticipantFeedback,
    ParticipantMoodAnswer,
    MoodQuestionMaster
)

from .schema import FeedbackCreate


class FeedbackRepository:

    @staticmethod
    def create_feedback(
        db: Session,
        payload: FeedbackCreate
    ):
        feedback = ParticipantFeedback(
            participant_id=payload.participant_id,
            lms_experience=payload.lms_experience,
            lms_ease=payload.lms_ease,
            useful_modules=json.dumps(
                payload.useful_modules
            )
        )

        db.add(feedback)
        db.flush()

        # Save mood question answers
        for mood_answer in payload.mood_answers:

            for option_id in mood_answer.selected_options:

                answer = ParticipantMoodAnswer(
                    participant_id=payload.participant_id,
                    question_id=mood_answer.question_id,
                    selected_option_id=option_id,
                    answer_time=date.today()
                )

                db.add(answer)

        db.commit()
        db.refresh(feedback)

        return feedback

    @staticmethod
    def get_questions_by_language(
        db: Session,
        language_id: int
    ):
        return (
            db.query(MoodQuestionMaster)
            .options(
                joinedload(
                    MoodQuestionMaster.options
                )
            )
            .filter(
                MoodQuestionMaster.language_id == language_id,
                MoodQuestionMaster.is_active == 1
            )
            .order_by(
                MoodQuestionMaster.question_id
            )
            .all()
        )