from typing import List, Optional

from pydantic import BaseModel, Field


class MoodAnswerCreate(BaseModel):
    question_id: int
    selected_options: List[int]


class FeedbackCreate(BaseModel):
    participant_id: int
    lms_experience: str
    lms_ease: str
    useful_modules: List[str]

    # Mood questionnaire answers
    mood_answers: List[MoodAnswerCreate]


class FeedbackResponse(BaseModel):
    feedback_id: int
    message: str

    class Config:
        from_attributes = True


class QuestionOptionResponse(BaseModel):
    option_id: int
    question_id: int
    option_name: str
    option_icon: Optional[str] = None
    language_id: int

    class Config:
        from_attributes = True


class MoodQuestionResponse(BaseModel):
    question_id: int
    question_name: str
    question_description: Optional[str] = None
    question_type: str
    language_id: int

    options: List[QuestionOptionResponse] = Field(
        default_factory=list
    )

    class Config:
        from_attributes = True


class MoodQuestionsResponse(BaseModel):
    questions: List[MoodQuestionResponse]

    class Config:
        from_attributes = True